package com.example.a201813709028;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.Toolbar;

import java.util.ArrayList;

public class Rehber extends AppCompatActivity {
    private ArrayList<Kisi> persons;
    private RecyclerView recyclerView;
    private Toolbar toolbar;
    private PersonRecyclerAdapter personRecyclerAdapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rehber);

        persons = new ArrayList<>();
        viewSettings();
        fillTheArray();
    }

    private void viewSettings() {
        recyclerView = findViewById(R.id.recycler_view);
        personRecyclerAdapter = new PersonRecyclerAdapter(persons);
        recyclerView.setAdapter(personRecyclerAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager((this)));
    }

    private void fillTheArray(){
        persons.add(new Kisi(R.drawable.ic_launcher_foreground ,"Ali", "+90 544 698 6525"));
        persons.add(new Kisi(R.drawable.ic_launcher_foreground, "Veli", "+90 534 698 1232"));
        persons.add(new Kisi(R.drawable.ic_launcher_foreground, "mehmet", "+90 584 788 8655"));
        persons.add(new Kisi(R.drawable.ic_launcher_foreground,  "ayşe", "+90 544 698 6525"));
        persons.add(new Kisi(R.drawable.ic_launcher_foreground,  "fatma", "+90 544 698 6525"));
        persons.add(new Kisi(R.drawable.ic_launcher_foreground,  "hayri", "+90 544 698 6525"));
        persons.add(new Kisi(R.drawable.ic_launcher_foreground,  "samet", "+90 544 698 6525"));
        persons.add(new Kisi(R.drawable.ic_launcher_foreground,  "kemal", "+90 544 698 6525"));

    }
}